# -*- coding: utf-8 -*-
"""
Created on Sat Mar 26 14:22:58 2022

@author: josep
"""

